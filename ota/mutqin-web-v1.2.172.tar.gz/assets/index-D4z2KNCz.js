const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CIOXv_0T.js","assets/index-rKui4Iko.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-rKui4Iko.js";const o=r("Share",{web:()=>t(()=>import("./web-CIOXv_0T.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
