const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-6QnRQY2O.js","assets/index-C3oHA4dL.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-C3oHA4dL.js";const _=e("Browser",{web:()=>o(()=>import("./web-6QnRQY2O.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
