const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CG6OyCjG.js","assets/index-C3oHA4dL.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C3oHA4dL.js";const o=r("Share",{web:()=>t(()=>import("./web-CG6OyCjG.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
