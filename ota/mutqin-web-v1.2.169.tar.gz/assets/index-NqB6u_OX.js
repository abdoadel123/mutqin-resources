const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DJf_FtK4.js","assets/index-C3oHA4dL.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-C3oHA4dL.js";const _=p("App",{web:()=>r(()=>import("./web-DJf_FtK4.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
