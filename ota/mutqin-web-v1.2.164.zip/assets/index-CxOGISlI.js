const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DXeeJxlt.js","assets/index-DVZmwxvK.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DVZmwxvK.js";const _=p("App",{web:()=>r(()=>import("./web-DXeeJxlt.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
