const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-jOJJQlSs.js","assets/index-DapgI5Ef.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DapgI5Ef.js";const o=r("Share",{web:()=>t(()=>import("./web-jOJJQlSs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
