const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DvDSN328.js","assets/index-DapgI5Ef.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DapgI5Ef.js";const _=e("Browser",{web:()=>o(()=>import("./web-DvDSN328.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
