const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dl7dmDrQ.js","assets/index-DapgI5Ef.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DapgI5Ef.js";const _=p("App",{web:()=>r(()=>import("./web-Dl7dmDrQ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
