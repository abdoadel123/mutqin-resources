const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CeU25m9s.js","assets/index-CwsRdGzX.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-CwsRdGzX.js";const _=e("Browser",{web:()=>o(()=>import("./web-CeU25m9s.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
