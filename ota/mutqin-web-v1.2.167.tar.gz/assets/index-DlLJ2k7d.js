const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-gJzD_GRy.js","assets/index-Bc5pulql.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-Bc5pulql.js";const _=e("Browser",{web:()=>o(()=>import("./web-gJzD_GRy.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
