const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dh8HGrw3.js","assets/index-Bc5pulql.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bc5pulql.js";const o=r("Share",{web:()=>t(()=>import("./web-Dh8HGrw3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
