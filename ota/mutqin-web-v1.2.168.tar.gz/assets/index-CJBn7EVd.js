const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-5Q45Ah-2.js","assets/index-BSAhNV_c.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BSAhNV_c.js";const _=p("App",{web:()=>r(()=>import("./web-5Q45Ah-2.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
