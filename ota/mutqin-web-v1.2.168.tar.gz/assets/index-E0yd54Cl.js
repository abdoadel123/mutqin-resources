const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C3wM84TS.js","assets/index-BSAhNV_c.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BSAhNV_c.js";const o=r("Share",{web:()=>t(()=>import("./web-C3wM84TS.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
