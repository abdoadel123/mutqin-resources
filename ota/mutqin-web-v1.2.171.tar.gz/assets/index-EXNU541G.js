const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dwnm28tx.js","assets/index-Bzqo-SUu.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Bzqo-SUu.js";const _=p("App",{web:()=>r(()=>import("./web-Dwnm28tx.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
