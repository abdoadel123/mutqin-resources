const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CMeI2NC_.js","assets/index-Bzqo-SUu.js","assets/index-Ca-xzJQg.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bzqo-SUu.js";const o=r("Share",{web:()=>t(()=>import("./web-CMeI2NC_.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
