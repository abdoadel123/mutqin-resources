const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web--2n9yZ0l.js","assets/index-CIvzQeQU.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CIvzQeQU.js";const o=r("Share",{web:()=>t(()=>import("./web--2n9yZ0l.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
