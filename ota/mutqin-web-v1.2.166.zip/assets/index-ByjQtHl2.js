const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CxX1pf50.js","assets/index-CIvzQeQU.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-CIvzQeQU.js";const _=e("Browser",{web:()=>o(()=>import("./web-CxX1pf50.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
