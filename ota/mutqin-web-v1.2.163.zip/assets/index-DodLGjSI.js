const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C5fnRE5k.js","assets/index-CGBMhS-P.js","assets/index-B5664Nzd.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CGBMhS-P.js";const o=r("Share",{web:()=>t(()=>import("./web-C5fnRE5k.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
